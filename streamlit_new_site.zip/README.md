
# Streamlit New Site (Starter)

## โครงสร้าง
- `app.py` — หน้า Home
- `pages/1_👤_Profile.py` — โปรไฟล์
- `pages/2_🔗_YouTube_Analysis.py` — ลิงก์/ฝัง Notion
- `pages/3_🥗_Healthy_vs_Junk_Food.py` — หน้าอัปโหลดโมเดล + รูปภาพ เพื่อพรีดิกต์
- `requirements.txt`
- `.streamlit/config.toml` — ธีม

## รันในเครื่อง
```
pip install -r requirements.txt
streamlit run app.py
```

## ดีพลอยบน Streamlit Community Cloud
1) สร้าง repo ใหม่บน GitHub แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2) ไปที่ https://streamlit.io/cloud → New app → เลือก repo/branch
3) Main file = `app.py` → Deploy
4) หน้า Food: อัปโหลดไฟล์โมเดล `best_model.pt` (ที่คุณเทรนไว้) แล้วอัปโหลดรูปเพื่อทำนาย
