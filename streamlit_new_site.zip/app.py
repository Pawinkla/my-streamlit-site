
import streamlit as st

st.set_page_config(page_title="My Data Apps", page_icon="🚀", layout="wide")
st.title("🚀 My Data Apps (Starter)")
st.markdown("""
ยินดีต้อนรับ! เลือกหน้าในแถบซ้าย:
- 👤 Profile
- 🔗 YouTube Analysis (ลิงก์/ฝัง Notion)
- 🥗 Healthy vs Junk Food (อัปโหลดโมเดล .pt แล้วทำนายจากรูป)
""")
st.info("ไปที่เมนูซ้ายเพื่อเลือกหน้าได้เลย")
